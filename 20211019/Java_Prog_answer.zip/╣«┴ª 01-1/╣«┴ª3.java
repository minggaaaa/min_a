class Five12Print
{
    public static void main(String[] args)
    {
        System.out.println(12);
        System.out.println("12");
        System.out.println("1" + "2");
        System.out.println("1" + 2);
        System.out.println(1 + "2");
    }
}
